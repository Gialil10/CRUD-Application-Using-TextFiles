﻿using System;
using System.Collections.Generic;
using DGestorProducto;
using MGestorProducto;

namespace BGestorProducto
{
    public class BProducto
    {
        private IDProducto dProducto = new DProducto();
       // private DProducto dProducto2 = new DProducto();



        // 1 Listar

        public List<MProducto> ListarProductos()
        {
            // Obține lista de produse din DProducto
            var productos = dProducto.ObtenerProductos(); 
            // Returnează lista de produse
            return productos; 
        }



        //2 Anadir elemento.
        public void AnadirProducto(MProducto producto)
        {
            // llama a metodo de DProducto pentru a para anadir el producto
            dProducto.AnadirProducto(producto);
           // Console.WriteLine("Producto añadido.");
        }


        //Borrar elemento pero solo comproba si existe o NO atraves de de metoda obtener() de desdede dproducto
        public bool BorrarProducto(int id)
        {
            // Obtiene la lista de productos desde DProducto
            var productos = dProducto.ObtenerProductos();

            // Busca el producto a borrar
            var productoABorrar = productos.Find(p => p.Id == id);

            // Si el producto existe
            if (productoABorrar != null)
            {
                // LLAMAR al METODO
               
                dProducto.BorrarProducto(id);
                // devuelve true si se ha borrado
                return true; 
            }
            else
            {
                return false; // DEVUELVE fals
                              // si no se encontra el producto
            }
        }

        
        // Este metodo lo usa modificar y comproba primero si existe y si existe devuelve true y entonces 
        //true y deja de modificar el bojecto creandelo en vista y pasandolo a busines  modificar  y luego a dat
       
        public bool Comproba_Existe__Producto(int idBuscar)

        {
                // Obtiene la lista de productos desde DProducto
                var productos = dProducto.ObtenerProductos();

                // Busca el producto a borrar
                var productoBuscar = productos.Find(p => p.Id == idBuscar);

                // Si el producto existe
                if (productoBuscar != null)
                {
                    // devuelve true si se ha encontrado
                    return true;
                }
                else
                {
                    return false; // DEVUELVE fals
                                 
                }
        }


        //Modificar un producto elemento.
        public bool ModificarProducto(int idBuscar, MProducto NuevoProducto)
        {
            // Llamar al metodo de DProducto para modificar el producto
            bool resultado = dProducto.ModificarProducto(idBuscar, NuevoProducto);
            
            {
                if (resultado is true)
                {
                    return true;
                }
                  return false;
            }

        
        }


        // Ver detalles de elemento con el id pasado comop parametro.

        public MProducto VerDetallesProducto(int id)
        {
            // Obtengo la lista con el id especifico
            var productos = dProducto.ObtenerProductos();

            // Buscar el producto por ID
            var producto = productos.Find(p => p.Id == id);

            if (producto != null)
            {
                // Si el productocon el id se encentra  lo devuelve
                return producto; 
            }
            else
            {
                // si no encuentra devuelve null
               
                return null;
            }
        }








        //Mostrar los elementos en base a un criterio.
        public List<MProducto> MostrarProductosPorCriterio(char nutriscore)
                 {
             
                 List<MProducto> productosFiltradosNutriscore = dProducto.MostrarProductosPorCriterio(nutriscore);             
                  
                   return productosFiltradosNutriscore;
                }



       
        // Mostrar los elementos en base a un criterio de fecha. (Ej. Productos despues de fecha de caducaciion despues
        //  de la fecha X)
      
        public List<MProducto> MostrarProductoCaducado(DateTime fechaCaducidadBuscar)
        {
            List<MProducto> productosCaducados= dProducto.MostrarProductoCaducado(fechaCaducidadBuscar);
            return productosCaducados;

        }
    }
}
