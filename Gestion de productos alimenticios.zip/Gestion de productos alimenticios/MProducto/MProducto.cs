﻿using System;

namespace MGestorProducto
{
    public class MProducto
    {
        private static int ultimoId = 0;
        public int id;
        public int Id { get; set; }

        public string Nombre { get; set; }
        public string Lote { get; set; }
        public bool Vegano { get; set; }
        public DateTime FechaProduccion { get; set; }
        public DateTime FechaCaducidad { get; set; }
        public double Precio { get; set; }
        public int Cantidad { get; set; }
        public char Nutriscore { get; set; }

        // Constructor vacío
        public MProducto()
        {
            this.Id = ++ultimoId; 
            this.Nombre = "";
            this.Lote = "";
            this.Vegano = false; 
            this.FechaProduccion = DateTime.MinValue; 
            this.FechaCaducidad = DateTime.MinValue; 
            this.Precio = 0.0;
            this.Cantidad = 0; 
            this.Nutriscore = 'A';
        }

       
        public MProducto(string nombre, string lote, bool vegano, DateTime fechaProduccion,
                         DateTime fechaCaducidad, double precio, int cantidad, char nutriscore)
        {
            this.Id = ++ultimoId;
            this.Nombre = nombre;
            this.Lote = lote;
            this.Vegano = vegano;
            this.FechaProduccion = fechaProduccion;
            this.FechaCaducidad = fechaCaducidad;
            this.Precio = precio;
            this.Cantidad = cantidad;
            this.Nutriscore = nutriscore;
        }

      
        public override string ToString()
        {
            return $"Nombre: {Nombre}, ID: {Id}, Lote: {Lote}, Vegano: {Vegano}, " +
                   $"Fecha de Producción: {FechaProduccion.ToShortDateString()}, " +
                   $"Fecha de Caducidad: {FechaCaducidad.ToShortDateString()}, " +
                   $"Precio: {Precio:Euro}, Cantidad: {Cantidad}, Nutriscore: {Nutriscore}";
        }
    }
}
