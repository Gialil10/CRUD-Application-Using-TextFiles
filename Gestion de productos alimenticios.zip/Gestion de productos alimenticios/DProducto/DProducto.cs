﻿using MGestorProducto;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Xml.Linq;

namespace DGestorProducto
{
    public class DProducto : IDProducto
    {
        //de aqui accede a fichero
        // Ruta del archivo de texto
    
        static string rutaArchivo = "Productos.txt";

      //  public static int Id { get; private set; }


        //  La aplicación deberá permitir hacer un listado de los elementos registrados.
        public static List<MProducto> ListarProductos(string rutaArchivo)
        {
            List<MProducto> productos = new List<MProducto>();

            using (FileStream fs = new FileStream(rutaArchivo, FileMode.Open, FileAccess.Read))
            using (StreamReader sr = new StreamReader(fs))
            {
                string linea;

                // Citește prima linie (header) și o ignorăm
                sr.ReadLine();

                while ((linea = sr.ReadLine()) != null)
                {
                    var parts = linea.Split(',');

                    if (parts.Length == 9) // Asigură-te că sunt 9 părți
                    {
                        var producto = new MProducto
                        {
                            id = int.Parse(parts[0]), // Aici este bine să utilizezi constructorul cu parametri în loc de setare directă
                            Nombre = parts[1],
                            Lote = parts[2],
                            Vegano = bool.Parse(parts[3]),
                            FechaProduccion = DateTime.Parse(parts[4]),
                            FechaCaducidad = DateTime.Parse(parts[5]),
                            Precio = double.Parse(parts[6]),
                            Cantidad = int.Parse(parts[7]),
                            Nutriscore = char.Parse(parts[8])
                        };
                        //Add el producto en la lista
                        productos.Add(producto); 
                    }
                }
            }

            return productos; // devuelve lista de produse
        }





        //Add element
       
        public void AnadirProducto(MProducto producto)
        {
            int nouId = 1; // ID default

            // Get all existing products to determine the next ID
            var existingProducts = ObtenerProductos();

            if (existingProducts.Count > 0)
            {
                // add from a¡max id 
                nouId = existingProducts.Max(p => p.Id) + 1; 
            }

            // Set ID of the new product
            producto.Id = nouId;

            // Write the new product to the file
            using (FileStream fs = new FileStream(rutaArchivo, FileMode.Append, FileAccess.Write))
            using (StreamWriter sw = new StreamWriter(fs))
            {
                sw.WriteLine($"{producto.Id},{producto.Nombre},{producto.Lote},{producto.Vegano}," +
                             $"{producto.FechaProduccion:yyyy-MM-dd},{producto.FechaCaducidad:yyyy-MM-dd}," +
                             $"{producto.Precio},{producto.Cantidad},{producto.Nutriscore}");
            }

            Console.WriteLine("Producto añadido.");
        }


        // Obtener productos desde el archivo
        public List<MProducto> ObtenerProductos()
        {
            List<MProducto> productos = new List<MProducto>();

            // Verifica si el archivo existe
            if (!File.Exists(rutaArchivo))
            {

                return productos; // Devuelve lista vaciia
            }

            // Lee el archivo y llena la lista de productos
            using (FileStream fs = new FileStream(rutaArchivo, FileMode.Open, FileAccess.Read))
            using (StreamReader sr = new StreamReader(fs))
            {
                string linea;

                // Lee la primera línea 
                sr.ReadLine();

                while ((linea = sr.ReadLine()) != null)
                {
                    var parts = linea.Split(',');

                    if (parts.Length == 9)
                    {
                        var producto = new MProducto
                        {
                            Id = int.Parse(parts[0]),
                            Nombre = parts[1],
                            Lote = parts[2],
                            Vegano = bool.Parse(parts[3]),
                            FechaProduccion = DateTime.Parse(parts[4]),
                            FechaCaducidad = DateTime.Parse(parts[5]),
                            Precio = double.Parse(parts[6]),
                            Cantidad = int.Parse(parts[7]),
                            Nutriscore = char.Parse(parts[8])
                        };

                        productos.Add(producto); // anadir el producto a la lista
                    }
                }
            }

            return productos;
        }




      
        // Borrar elemento.
        public bool BorrarProducto(int id)
        {
            // Obtener productos actuales
            var productos = ObtenerProductos();

            // Buscar el productopara borrar
            var productoABorrar = productos.Find(p => p.Id == id);

            if (productoABorrar != null)
            {
                // eliminar el producto de la lista
                productos.Remove(productoABorrar);

                
                for (int i = 0; i < productos.Count; i++)
                {
                    //Start from index 1
                    productos[i].Id = i + 1; 
                }

                
                GuardarProductos(productos);

                // devuelve true si esta borrado
                return true; 
            }
            else
            {
                return false; 
            }
        }





   
        public void GuardarProductos(List<MProducto> productos)
        {
            using (FileStream fs = new FileStream(rutaArchivo, FileMode.Create, FileAccess.Write))
            using (StreamWriter sw = new StreamWriter(fs))
            {
                // Escribir encabezado
                sw.WriteLine("ID,Nombre,Lote,Vegano,FechaProduccion,FechaCaducidad,Precio,Cantidad,Nutriscore");

                foreach (var producto in productos)
                {
                    // Escribir cada producto en el archivo
                    sw.WriteLine($"{producto.Id},{producto.Nombre},{producto.Lote},{producto.Vegano}," +
                                 $"{producto.FechaProduccion:yyyy-MM-dd},{producto.FechaCaducidad:yyyy-MM-dd}," +
                                 $"{producto.Precio},{producto.Cantidad},{producto.Nutriscore}");
                }
            }
        }



        //Modificar elemento.
        public bool ModificarProducto(int idBuscar, MProducto nuevoProducto)
        {
            // obtengo la lista de productos 
            var productos = ObtenerProductos();

            // busco el producto a atraves del id para modificar
            var index = productos.FindIndex(p => p.Id == idBuscar);

            // Si el producto existe
            if (index != -1)
            {
                // Modificar el producto en la lista original
                //paso en la lista de producto devuelta de metodo  ObtenerProductos();
                //a la posicion de index indice el nuvo producto pasado como parametro de entrada ( MProducto nuevoProducto))

                // guardar the original ID, only update other details
                nuevoProducto.Id = idBuscar;
                productos[index] = nuevoProducto;

                // Guardo la lista de productos  
               GuardarProductos(productos);


                return true;
            }
            else
            {
               
                return false;
            }
        }



        //para ver detalles de un producto atraves de un id introducid
        public void VerDetallesProducto(int id) {

            ObtenerProductos();
        
        }
       
       
        // Mostrar los elementos en base a un criterio (nutriscore).
        public List<MProducto> MostrarProductosPorCriterio(char nutriscore)
        {
            List<MProducto> productos2dev = new List<MProducto>();

            // Lee el archivo y llena la lista de productos.
            using (FileStream fs = new FileStream(rutaArchivo, FileMode.Open, FileAccess.Read))
            using (StreamReader sr = new StreamReader(fs))
            {
                string linea;

                // Lee la primera línea (encabezado).
                sr.ReadLine();

                while ((linea = sr.ReadLine()) != null)
                {
                    var parts = linea.Split(',');

                    // Verifica que la línea tiene la cantidad esperada de partes.
                    if (parts.Length == 9)
                    {
                        var producto2 = new MProducto
                        {
                            Id = int.Parse(parts[0]),
                            Nombre = parts[1],
                            Lote = parts[2],
                            Vegano = bool.Parse(parts[3]),
                            FechaProduccion = DateTime.Parse(parts[4]),
                            FechaCaducidad = DateTime.Parse(parts[5]),
                            Precio = double.Parse(parts[6]),
                            Cantidad = int.Parse(parts[7]),
                            Nutriscore = char.Parse(parts[8])
                        };

                        // Filtra los productos por el nutriscore .
                        if (producto2.Nutriscore == nutriscore)
                        {
                            productos2dev.Add(producto2);
                        }
                    }
                }
            }

            // Devuelve la lista de productos con el nutriscore buscado
            return productos2dev;
        }



        // Mostrar los elementos en base a un criterio de dataTime. (Ej. productos con la fecha caducada)
        public List<MProducto> MostrarProductoCaducado(DateTime fechaActual)
        {
           
            List<MProducto> todosLosProductos = ObtenerProductos();

            //   lista para almacenar los productos caducados
            List<MProducto> productosCaducados = new List<MProducto>();

            // 
            foreach (MProducto producto in todosLosProductos)
            {
                // Si la fecha de caducidad es anterior a la fecha actual, anadimos el producto a la lista de caducados (productosCaducados)
                if (producto.FechaCaducidad < fechaActual)
                {
                    productosCaducados.Add(producto);
                }
            }

            
            return productosCaducados;
        }


    }
}
