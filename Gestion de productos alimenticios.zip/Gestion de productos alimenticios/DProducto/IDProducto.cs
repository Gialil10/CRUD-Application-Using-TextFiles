﻿using MGestorProducto;
using System;
using System.Collections.Generic;

namespace DGestorProducto
{
    public interface IDProducto
    {
        List<MProducto> ObtenerProductos();  
        void GuardarProductos(List<MProducto> productos);
        void AnadirProducto(MProducto producto);
        bool BorrarProducto(int id);
        bool ModificarProducto(int id, MProducto productoModificado);
        void VerDetallesProducto(int id);
        List<MProducto> MostrarProductosPorCriterio(char nutriscore);
//  void MostrarProductoCaducado(DateTime fechaCaducidadBuscar);
        List<MProducto> MostrarProductoCaducado(DateTime fechaCaducidadBuscar);
    }
}
