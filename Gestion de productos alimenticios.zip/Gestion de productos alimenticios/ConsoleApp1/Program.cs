﻿using BGestorProducto;
using MGestorProducto;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.ConstrainedExecution;

namespace VConsola
{
    internal class Program
    {
        // Declare the product management instance via the interface
        private static BProducto bProducto = new BProducto();

        static void Main(string[] args)
        {
            int opcion;
            do
            {
                // Display menu
                Console.WriteLine("\n----- MENÚ -----");
                Console.WriteLine("1. Listar productos");
                Console.WriteLine("2. Añadir producto");
                Console.WriteLine("3. Borrar producto");
                Console.WriteLine("4. Modificar producto");
                Console.WriteLine("5. Ver detalles de producto con el id..");
                Console.WriteLine("6. Mostrar productos por criterio especifico Nutriscore");
                Console.WriteLine("7. Mostrar productos con la fecha de caducacion .");
                Console.WriteLine("0. Salir");
                Console.Write("Seleccione una opción: ");

                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    switch (opcion)
                    {
                        case 1:
                            List<MProducto> productos = bProducto.ListarProductos(); // Obține lista de produse
                            if (productos.Count == 0)
                            {
                                Console.WriteLine("Nu există produse în listă.");
                            }
                            else
                            {
                                Console.WriteLine("Lista de produse:");
                                foreach (var producto in productos)
                                {
                                    Console.WriteLine(producto); // Escribir cada prducto
                                }
                            }
                            break; 

                        case 2:
                            // Cod pentru a obține informațiile despre produs
                            Console.WriteLine("Introduce el nombre del producto:");
                            string nombre = Console.ReadLine();

                            Console.WriteLine("Introduce el lote del producto:");
                            string lote = Console.ReadLine();

                            Console.WriteLine("¿Es vegano? (true/false):");
                            bool vegano = bool.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce la fecha de producción (yyyy-MM-dd):");
                            DateTime fechaProduccion = DateTime.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce la fecha de caducidad (yyyy-MM-dd):");
                            DateTime fechaCaducidad = DateTime.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce el precio:");
                            double precio = double.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce la cantidad:");
                            int cantidad = int.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce el nutriscore (A/B/C):");
                            char nutriscore = char.Parse(Console.ReadLine().ToUpper());

                            // Crea el  objecto MProducto
                            MProducto nuevoProducto = new MProducto(nombre, lote, vegano, fechaProduccion, fechaCaducidad, precio, cantidad, nutriscore);
                            // Anadir el producto produsului
                            bProducto.AnadirProducto(nuevoProducto);
                            break;

                            
                        case 3:
                            ///para borrar primero comproba si existe
                           Console.WriteLine("Introduce el Id del producto que queres borrar");
                            int id =int.Parse(Console.ReadLine());
                            bProducto.BorrarProducto(id);
                            break;


                        //Introduce el producto para modifiacar
                        //Modificar elemento.
                        case 4:
                            Console.WriteLine("Introduce el id del producto");
                            int idBuscar = int.Parse(Console.ReadLine());
                            bProducto.Comproba_Existe__Producto(idBuscar);

                            
                            Console.WriteLine("Introduce el nombre del producto:");
                            string nombre2 = Console.ReadLine();

                            Console.WriteLine("Introduce el lote del producto:");
                            string lote2 = Console.ReadLine();

                            Console.WriteLine("¿Es vegano? (true/false):");
                            bool vegano2 = bool.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce la fecha de producción (yyyy-MM-dd):");
                            DateTime fechaProduccion2 = DateTime.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce la fecha de caducidad (yyyy-MM-dd):");
                            DateTime fechaCaducidad2 = DateTime.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce el precio:");
                            double precio2 = double.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce la cantidad:");
                            int cantidad2 = int.Parse(Console.ReadLine());

                            Console.WriteLine("Introduce el nutriscore (A/B/C):");
                            char nutriscore2 = char.Parse(Console.ReadLine().ToUpper());
                            // Crea el  objecto MProducto
                            MProducto NuevoProducto = new MProducto(nombre2, lote2, vegano2, fechaProduccion2, fechaCaducidad2, precio2, cantidad2, nutriscore2);
                            // Anadir el producto produsului
                            bProducto.ModificarProducto(idBuscar,NuevoProducto);
                            break;

                           // Ver detalles de elemento.aprtir del id
                        case 5:
                            Console.WriteLine("Introduce el id del producto que queres ver");                     
                           
                            int IdBuscar = int.Parse(Console.ReadLine());
                            //Devuelve si no existe o si existe el producto luego te va 
                            Console.WriteLine(bProducto.Comproba_Existe__Producto(IdBuscar));
                            Console.WriteLine(bProducto.VerDetallesProducto(IdBuscar));
                            
                            break;
                       
                            // productos con el nutriscore x
                        case 6:
                            Console.WriteLine("Introduce el nutriscore del productos que quieres ver:");
                            char nutriscoreBuscar = char.Parse(Console.ReadLine().ToUpper());

                            // Obține lista de produse filtrate
                            List<MProducto> productosFiltradosNutriscore = bProducto.MostrarProductosPorCriterio(nutriscoreBuscar);

                            // Verifică dacă lista este goală și printează produsele
                           
                                Console.WriteLine("Produse cu nutriscore-ul " + nutriscoreBuscar + ":");
                                foreach (var producto in productosFiltradosNutriscore)
                                {
                                    Console.WriteLine(producto.ToString()); 
                                }
                            
                            break;

                        //para ver los productos con la fecha caducada
                        /////por ejemplo introduce una fecha y muestra los `productos con la fecha inferiora a este fecha introducida
                        case 7:
                            Console.WriteLine("Introduce la fecha actual para ver los productos caducados:");

                            // pRSEAR the input date
                            DateTime fechaCaducidadBuscar;

                            if (DateTime.TryParse(Console.ReadLine(), out fechaCaducidadBuscar))
                            {
                                ///DEVUELVE UNA LISTA DE PRODUCTOS 
                                var productosCaducados = bProducto.MostrarProductoCaducado(fechaCaducidadBuscar);

                                Console.WriteLine("Productos caducados después de la fecha " + fechaCaducidadBuscar);

                                // COMPROBA SI LA LISTA NO ESTA VACIIA
                                if (productosCaducados != null && productosCaducados.Any())
                                {
                                    foreach (var producto in productosCaducados)
                                    {
                                        Console.WriteLine(producto.ToString()); 
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("No hay productos caducados con la fecha introducda");
                                }
                            }
                            else
                            {
                                Console.WriteLine("La fecha introducida no es valida.");
                            }
                            break;


                        case 0:
                            Console.WriteLine("Cerrar Gracias por usar nuestro producto ...");
                            break;
                        default:
                            Console.WriteLine("Opcion no valida. Intente de nuevo.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Entrada no valida. Intente de nuevo.");
                }
            } while (opcion != 0);
        }
    }
}